# Hybrid AI Flow Diagram

## Complete Message Processing Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                    USER SENDS MESSAGE                            │
│             "Hello!" or "Book appointment"                       │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                   WEBHOOK RECEIVED                               │
│        Facebook/Instagram → Meta-Bot Server                      │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                 COMPANY LOOKUP                                   │
│    Get company settings: ai_provider, system_instructions        │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│               CHECK AI PROVIDER                                  │
│                                                                  │
│   ai_provider = "gemini" OR USE_GEMINI=true?                    │
│                                                                  │
│          YES ↓                           NO ↓                    │
│    ┌──────────────┐              ┌──────────────┐              │
│    │ USE GEMINI   │              │ USE OPENAI   │              │
│    │ (Hybrid)     │              │ (Traditional)│              │
│    └──────┬───────┘              └──────┬───────┘              │
└───────────┼──────────────────────────────┼──────────────────────┘
            │                              │
            │                              └──────────────┐
            │                                             │
            ▼                                             ▼
┌──────────────────────────────┐           ┌──────────────────────────────┐
│   GEMINI AGENT NODE          │           │   OPENAI AGENT NODE          │
│                              │           │                              │
│ 1. Load conversation history │           │ 1. Load conversation history │
│ 2. Prune to 15 messages      │           │ 2. Prune to 15 messages      │
│ 3. Add system instructions   │           │ 3. Add system instructions   │
│ 4. Call Gemini 1.5 Flash/Pro │           │ 4. Call OpenAI GPT-4o        │
│ 5. Get response              │           │ 5. Get response              │
└──────────────┬───────────────┘           └──────────────┬───────────────┘
               │                                          │
               │ Gemini Response                          │ OpenAI Response
               │                                          │
               ▼                                          ▼
    ┌──────────────────────┐                  ┌──────────────────────┐
    │ Check Response Type  │                  │ Check Response Type  │
    └──────────┬───────────┘                  └──────────┬───────────┘
               │                                          │
       ┌───────┴────────┐                        ┌───────┴────────┐
       │                │                        │                │
       ▼                ▼                        ▼                ▼
┌─────────────┐  ┌─────────────┐        ┌─────────────┐  ┌─────────────┐
│ TEXT ONLY   │  │ TOOL CALLS  │        │ TEXT ONLY   │  │ TOOL CALLS  │
│ (70-80%)    │  │ (20-30%)    │        │             │  │             │
└──────┬──────┘  └──────┬──────┘        └──────┬──────┘  └──────┬──────┘
       │                │                       │                │
       │                │                       │                │
       │         ┌──────┴──────────┐            │                │
       │         │ SWITCH TO       │            │                │
       │         │ OPENAI!         │            │                │
       │         │                 │            │                │
       │         │ Reason: Tools   │            │                │
       │         │ need reliable   │            │                │
       │         │ execution       │            │                │
       │         └────────┬────────┘            │                │
       │                  │                     │                │
       │                  ▼                     │                │
       │         ┌──────────────────┐           │                │
       │         │ OpenAI Agent     │           │                │
       │         │ with Tools       │           │                │
       │         └────────┬─────────┘           │                │
       │                  │                     │                │
       │                  ▼                     │                │
       │         ┌──────────────────┐           │                │
       │         │ Execute Tools    │───────────┤                │
       │         │ (book, cancel,   │           │                │
       │         │  get_times, etc) │           │                │
       │         └────────┬─────────┘           │                │
       │                  │                     │                │
       └──────────────────┴─────────────────────┴────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                   SEND RESPONSE                                  │
│         "Hi there!" or "Booked for Jan 5 at 2pm"                │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                  TRACK METRICS                                   │
│                                                                  │
│  Provider: gemini | openai | gemini-to-openai-switch            │
│  Execution Time: 500ms                                           │
│  Cost: $0.0001 (Gemini) or $0.005 (OpenAI)                     │
└─────────────────────────────────────────────────────────────────┘
```

## Decision Matrix

### When Gemini is Enabled (USE_GEMINI=true)

| Message Type | First Handler | Final Handler | Why? |
|-------------|---------------|---------------|------|
| "Hello!" | Gemini | **Gemini** | Text only, no tools needed |
| "What are your hours?" | Gemini | **Gemini** | Simple question, no tools |
| "Thanks!" | Gemini | **Gemini** | Acknowledgment, no tools |
| "Book appointment tomorrow" | Gemini | **OpenAI** | Detected tool call → switch |
| "Show my bookings" | Gemini | **OpenAI** | Detected tool call → switch |
| "Cancel my appointment" | Gemini | **OpenAI** | Detected tool call → switch |

### When Gemini is Disabled (USE_GEMINI=false)

| Message Type | Handler | Why? |
|-------------|---------|------|
| All messages | **OpenAI** | Single provider mode |

## Cost Breakdown by Flow

### Flow 1: Text-Only Response (Gemini)

```
User: "Hello, how are you?"
    ↓
Gemini processes: 50 tokens input, 30 tokens output
    ↓
Cost: 50 * $0.35 / 1M = $0.0000175
      30 * $1.05 / 1M = $0.0000315
    ↓
Total: $0.000049 (~$0.00005) ✅ VERY CHEAP!
```

### Flow 2: Tool Call (Gemini → OpenAI)

```
User: "Book appointment for tomorrow at 2pm"
    ↓
Gemini processes: 200 tokens input, 50 tokens output (detects tool)
Cost: $0.00009
    ↓
Switch to OpenAI
    ↓
OpenAI processes: 200 tokens input, 150 tokens output
  + 3 tool calls (get_customer_info, get_available_times, book_appointment)
  + Tool results: 300 tokens
Cost: $0.0015
    ↓
Total: $0.00009 + $0.0015 = $0.00159 (~$0.0016) ✅ STILL CHEAP!
```

### Flow 3: OpenAI Only (Traditional)

```
User: "Hello, how are you?"
    ↓
OpenAI processes: 50 tokens input, 30 tokens output
    ↓
Cost: 50 * $2.50 / 1M = $0.000125
      30 * $10 / 1M = $0.0003
    ↓
Total: $0.000425 (~$0.00043) ❌ 8.6x MORE EXPENSIVE!
```

## Provider Distribution (Typical Usage)

Based on 1000 messages per day:

```
┌─────────────────────────────────────────────────────────┐
│           MESSAGE TYPE DISTRIBUTION                      │
└─────────────────────────────────────────────────────────┘

TEXT ONLY (70%)                 ███████████████████████████████████
├─ Greetings                    │ 700 msgs/day
├─ Questions                    │ Gemini only
├─ Follow-ups                   │ Cost: $0.03/day
└─ Acknowledgments              │
                                │
TOOL CALLS (30%)                ███████████████
├─ Bookings                     │ 300 msgs/day
├─ Cancellations                │ Gemini → OpenAI switch
├─ Service inquiries            │ Cost: $0.48/day
└─ Pet management               │

TOTAL DAILY COST (HYBRID):      $0.51/day = $15.30/month
TOTAL DAILY COST (OPENAI):      $1.25/day = $37.50/month

SAVINGS: $22.20/month (59% reduction) 💰
```

## Error Handling Flow

```
┌─────────────────────────────────────────────────────────────────┐
│              GEMINI ERROR HANDLING                               │
└─────────────────────────────────────────────────────────────────┘

User Message
    ↓
Gemini Agent
    ↓
    ├─ Success → Return response ✅
    │
    └─ Error → Check error type
               │
               ├─ API Key Invalid
               ├─ Rate Limit
               ├─ Network Error
               └─ Internal Error
                    ↓
           ┌────────────────────┐
           │ AUTOMATIC FALLBACK │
           │ TO OPENAI          │
           └────────┬───────────┘
                    │
                    ▼
           OpenAI Agent (Retry)
                    │
                    ├─ Success → Return response ✅
                    │
                    └─ Error → Return error message ❌
                               "I'm having trouble..."
```

## Configuration Impact

### Config: USE_LANGGRAPH=false

```
All messages → Legacy OpenAI (no hybrid, no Gemini)
```

### Config: USE_LANGGRAPH=true, USE_GEMINI=false

```
All messages → OpenAI Agent (LangGraph, no Gemini)
```

### Config: USE_LANGGRAPH=true, USE_GEMINI=true

```
Text messages → Gemini Agent ✅
Tool messages → OpenAI Agent ✅
(HYBRID MODE - RECOMMENDED)
```

## Real Example from Logs

### Successful Hybrid Flow:

```
19:57:56 [LangGraph] Using GEMINI as AI provider
19:57:56 [gemini-agent-node] Processing with 20 messages
19:57:56 [gemini-tool-calls-detected] Gemini detected 2 tool calls
19:57:56 [gemini-to-openai-switch] Switching to OpenAI for tools
19:57:56 [agent-node] Processing with 20 messages
19:58:19 [agent-response] Received text response
```

**Result:** Started with Gemini, switched to OpenAI for tools ✅

---

**Last Updated:** 2025-01-04
**Diagram Version:** 1.0
