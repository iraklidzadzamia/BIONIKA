export { default as LocationsSection } from "./LocationsSection";
export { default as CompanyInfoSection } from "./CompanyInfoSection";
export { default as ServicesSection } from "./ServicesSection";
export { default as ResourcesSection } from "./ResourcesSection";
export { default as WorkingHoursSection } from "./WorkingHoursSection";
export { default as IntegrationsSection } from "./IntegrationsSection";
