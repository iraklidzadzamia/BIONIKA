"use client";
import { LoginPage } from "@/features/auth";

export default function Page() {
  return <LoginPage />;
}
