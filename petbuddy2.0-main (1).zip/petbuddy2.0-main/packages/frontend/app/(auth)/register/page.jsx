"use client";
import { RegisterPage } from "@/features/auth";

export default function Page() {
  return <RegisterPage />;
}
